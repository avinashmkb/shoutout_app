
		
//bar graph begin
$(function() {

    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'container2',
                type: 'bar',
				backgroundColor: 'none',


                
            },
            title: {
                text: ''
            },
            legend: {
                enabled: 'true',
                padding: 4.5
            },
            exporting: {
                buttons: {
                    exportButton: {
                        enabled: false
                    },
                    printButton: {
                        enabled: false
                    }

                }
            },
            xAxis: {
                max: 2,
                color: '#fb9817',
                categories: ['Service', 'Product', 'Process']

            },
            yAxis: {
                min: 0,
                title: {
                    text: ''
                }
            },
            plotOptions: {
                bar: {
               
                    allowPointSelect: true,
                    pointHeight: 52,
                    cursor: 'pointer',

                },
                series: {
                    stacking: 'normal',
                    borderRadius: 3,
                   cursor: 'pointer',
                    point: {
                        events: {
                            click: function(event) {
             console.log(this.url);window.open(this.url,'_self');
                            }
                        }
                    }
                }
            },
            series: [{
                name: 'Neutral',
                color: '#f7d009',
                data: [{
                    y: 7,
                    url: 'Feedbacks/Feedbacks%20Service%20Neutral.html'}, 
					{y:32,
					 url:'Feedbacks/Feedbacks%20Products%20Neutral.html'}, 
					 {y:38,
					  url:'Feedbacks/Feedbacks%20Process%20Neutral.html'
					 }]},
            
			
			{
                name: 'Negative',

                color: '#f47359',
                data: [{
                    y: 233,
                    url: 'Feedbacks/Feedbacks%20Service%20Negative.html'},
					{ y:78, 
					url:'Feedbacks/Feedbacks%20Products%20negative.html'}, 
					{y:110,
					url:'Feedbacks/Feedbacks%20Process%20Negative.html'}
					
					]},
            {
                name: 'Positive',
                color: '#3acb3a',
                data: [{
                    y: 25,
                    url: 'Feedbacks/Feedbacks%20Servicepostive.html'}, 
					{y:125, 
					url:'Feedbacks/Feedbacks%20Products%20Positive.html'}, 
					{y:82, 
					url:'Feedbacks/Feedbacks%20Process%20positive.html'}]

                }]



        },function(chart){
       console.log(chart.series[0].data[0].url);
    });
    });

}); //ice cream bar end​​



//Gauge code beginning
$(document).ready(function(e) {
$('#test').speedometer();
$('.changeSpeedometer').click(function(){
$('#test').speedometer({ percentage: $('.speedometer').val() || -1 });
});
});
//Gauge code Ending


//bar with line chart start
var chart;
$(document).ready(function() {
	chart = new Highcharts.Chart({
		chart: {
			renderTo: 'container3',
		backgroundColor: 'none'
		},
	exporting: {
    buttons: { 
        exportButton: {
            enabled:false
        },
        printButton: {
            enabled:false
        }

    }
},
		title: {
			text: ''
		},
		
		xAxis:
		[{
			categories: ['2010', '2011', '2012'],
				
		}],
		yAxis: [{ // Primary yAxis
			title: {
			text: 'Net Score'
		},
	
			
		}, { // Secondary yAxis
			title: {
				text: 'Total FeedBacks',
				
			},
			labels: {
				formatter: function() {
					return this.value +'score';
				},
				style: {
					color: '#999999'
				}
			},
			opposite: true
		}],
		tooltip: {
			formatter: function() {
				return ''+
					this.x +': '+ this.y +
					(this.series.name == 'Comments' ? ' sms' : ' score');
			}
		},
		
			legend: {
			enabled:true,
			y:10,
			x:-1,
			width:310,
			padding:4.5
		},
		series: [{
			name: 'Comments',
			color: '#999',
			 cursor: 'pointer',
			 borderColor:'#333',
			type: 'column',
			yAxis: 1,
			data: [138,576,142]

		}, {
			name: 'Product',
			color: '#502b54',
			cursor: 'pointer',
			type: 'spline',
			data: [0.3, 0.041, 0.189]
		},
		 {
			name: 'Service',
			color: '#f7d009',
			cursor: 'pointer',
			type: 'spline',
			data: [-0.686, -0.74, -0.673]
		},
		 {
			name: 'Process',
			color: '#fb9817',
			cursor: 'pointer',
			type: 'spline',
			data: [-0.14, -0.091, -0.073]
		}
		]
	});
});//bar with line chart end
		
