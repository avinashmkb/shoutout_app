// JavaScript Document


//Pie chart
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
				renderTo: 'piechart',
				backgroundColor:'transparent',
				marginTop:-12,
				margin:0 ,
		
                },
				legend: {
			verticalAlign: 'right',
            x: -2,
            y: 265,
			width:235, padding:4.5
        },
			exporting: {
    buttons: { 
        exportButton: {
            enabled:false
        },
        printButton: {
            enabled:false
        }

    }
},
            title: {
                text: ''
            },
            tooltip: {
                formatter: function() {
                    return '<b>'+ this.point.name +'</b>: '+ this.percentage +' %';
                }
            },
            plotOptions: {
                pie: {
                    size:'80%',
					allowPointSelect: true,
                   
                   dataLabels: {
                        enabled: true,
						 softConnector: false,
						 distance:-25,
						 color:'#333',
						
                        style: {
                        fontWeight: 'bold'
                               }
						
                        
                    },
					showInLegend: true
                }
            },
			
            series: [{
                type: 'pie',
				name: '',
                data: [
                    { name:'Positive',
				      y:30.8,
					   color:'#3acb3a',
					   
					  
					  },
                    { name:'Negative',
					  y:55.8,
					  color:'#f47359'},
                    {
                        name: 'Neutral',
                        y: 13.4,
                      color:'#f7d009',
					  sliced:true
					
                    },

                ]
            }],
			
			
        });
    });
    
});


