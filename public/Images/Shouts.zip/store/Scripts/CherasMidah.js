
		
//bar graph begin
$(function() {

    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'container2',
                type: 'bar',

                backgroundColor: {
                    linearGradient: [0, 0, 0, 400],
                    stops: [
                        [0, 'rgb(246,246,246)'],
                        [1, 'rgb(223,223,223)']
                        ]
                },
            },
            title: {
                text: ''
            },
            legend: {
                enabled: 'true',
                padding: 4.5
            },
            exporting: {
                buttons: {
                    exportButton: {
                        enabled: false
                    },
                    printButton: {
                        enabled: false
                    }

                }
            },
            xAxis: {
                max: 2,
                color: '#fb9817',
                categories: ['Service', 'Product', 'Process']

            },
            yAxis: {
                min: 0,
                title: {
                    text: ''
                }
            },
            plotOptions: {
                bar: {
                    backgroundColor: {
                        linearGradient: [0, 0, 0, 400],
                        stops: [
                            [0, 'rgb(246,246,246)'],
                            [1, 'rgb(223,223,223)']
                            ]
                    },
                    allowPointSelect: true,
                    pointHeight: 52,
                    cursor: 'pointer',

                },
                series: {
                    stacking: 'normal',
                    borderRadius: 3,
                    plotBackgroundImage: 'Images/2.png',
                    cursor: 'pointer',
                    point: {
                        events: {
                            click: function(event) {
             console.log(this.url);window.open(this.url,'_self');
                            }
                        }
                    }
                }
            },
                series:[{
					 name: 'Neutral',
				color:'#f7d009', 
                data: [{y:0,url:'#'},{y:0,url:'#'},{y:5,url:'../Feedbacks/Processneutral(cherasmidah).html'}]},
					
			{
                name: 'Negative',
			
				color:'#f47359',
                data: [{y:43,url:'../Feedbacks/Servicenegative(cherasmidah).html'},
				       {y:11,url:'../Feedbacks/ProductsNegative(cherasmidah).html'},
					   {y:22,url:'../Feedbacks/Processnegative(cherasmidah).html'}]
            }, 
			
			{
			name: 'Positive',
				color:'#3acb3a',
                data: [{y:1,url:'../Feedbacks/Servicepositive(cherasmidah).html'},
				       {y:35,url:'../Feedbacks/Productspositve%20(cherasmidah).html'},
					   {y:6,url:'../Feedbacks/Processpositive(cherasmidah).html'}]
				
				
				
				
            }]
			
        },function(chart){
       console.log(chart.series[0].data[0].url);
		}); 
    });
    
});//ice cream bar end



//Gauge code beginning
$(document).ready(function(e) {
$('#test').speedometer();
$('.changeSpeedometer').click(function(){
$('#test').speedometer({ percentage: $('.speedometer').val() || -1 });
});
});
//Gauge code Ending


//bar with line chart start
var chart;
$(document).ready(function() {
	chart = new Highcharts.Chart({
		chart: {
			renderTo: 'container3',
			
			backgroundColor:'none'
,
		},
	exporting: {
    buttons: { 
        exportButton: {
            enabled:false
        },
        printButton: {
            enabled:false
        }

    }
},
		title: {
			text: ''
		},
		
		xAxis:
		[{
			categories: ['2010','2011','2012'],
				
		}],
		yAxis: [{ // Primary yAxis
			title: {
			text: 'Net Score'
		},
	
			
		}, { // Secondary yAxis
			title: {
				text: 'Total FeedBacks',
				
			},
		labels: {
				formatter: function() {
					return this.value +' sms';
				},
				style: {
					color: '#999999'
				}
			},
			opposite: true
		}],
		tooltip: {
			formatter: function() {
				return ''+
					this.x +': '+ this.y +
					(this.series.name == 'Comments' ? ' sms' : 'score');
			}
		},
		
		legend: {
			enabled:true,
			y:10,
			x:1,
			width:310,padding:4.5
		},
		series: [{
			name: 'Comments',
			color: '#999',
			borderColor:'#333',
			 cursor: 'pointer',
			type: 'column',
			yAxis: 1,
			data: [27,79,17]

		}, {
			name: 'Product',
			color: '#502b54',
			cursor: 'pointer',
			type: 'spline',
			data: [0.536,0.212,0.75]
		},
		 {
			name: 'Service',
			color: '#f7d009',
			cursor: 'pointer',
			type: 'spline',
			data: [-0.417,-0.983,-0.7]
		},
		 {
			name: 'Process',
			color: '#fb9817',
			cursor: 'pointer',
			type: 'spline',
			data: [-0.786,-0.225,-0.667]
		}
		]
	});
});//bar with line chart end
		
		