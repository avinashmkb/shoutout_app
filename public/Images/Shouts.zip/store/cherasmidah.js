// JavaScript Document
//Pie chart
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
				renderTo: 'piechartCheras',
				marginTop:-15,
				margin:0 ,
		backgroundColor:'none'
      
                },
			legend: {
			verticalAlign: 'right',
            x: -2,
            y: 265,
			width:235, padding:4.5
        },
			exporting: {
    buttons: { 
        exportButton: {
            enabled:false
        },
        printButton: {
            enabled:false
        }

    }
},
            title: {
                text: ''
            },
            tooltip: {
                formatter: function() {
                    return '<b>'+ this.point.name +'</b>: '+ this.percentage +' %';
                }
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
					size:'80%',
                    cursor: 'pointer',
					
					
					
                   dataLabels: {
                        enabled: true,
						 softConnector: false,
						 distance:9,
						 color:'#333'
						
                        
                    },
					showInLegend: true
                }
            },
			
            series: [{
                type: 'pie',
				name: '',
                data: [
                    { name:'Positive',
				      y:32.82,
					 color:'#3acb3a',
					  sliced: true,
					  
					  },
                    { name:'Negative',
					  y:58.78,
					  color:'#f47359'},
                    {
                        name: 'Neutral',
                        y: 8.40,
                       
                       
						color:'#f7d009'
						
						
                    },
                    
                   
                   
                ]
            }],
			
			
        });
    });
    
});

		